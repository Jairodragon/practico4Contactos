package com.example.practico4.models

data class Phone(
    val id: Int,
    val label: String, // "Casa", "Trabajo", "Celular" o personalizada
    val number: String
)
