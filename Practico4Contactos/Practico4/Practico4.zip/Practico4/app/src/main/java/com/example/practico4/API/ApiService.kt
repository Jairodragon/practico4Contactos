package com.example.practico4.API

import com.example.practico4.Models.Contact
import com.example.practico4.Models.Email
import com.example.practico4.Models.Phone
import okhttp3.MultipartBody
import retrofit2.Call
import retrofit2.http.*

interface ApiService {
    @GET("personas")
    fun getContacts(): Call<List<Contact>>

    @GET("search")
    fun searchContacts(@Query("q") query: String): Call<List<Contact>>

    @POST("personas")
    fun crearContacto(@Body contacto: Contact): Call<Void>

    @POST("personas") // Asegúrate de que la ruta sea correcta
    fun addContact(@Body contact: Contact): Call<Contact>

    @PUT("personas/{id}")
    fun updateContact(@Path("id") id: Int, @Body contact: Contact): Call<Contact>

    @DELETE("personas/{id}")
    fun deleteContact(@Path("id") id: Int): Call<Void>

    @POST("phones")
    fun addPhone(@Body phone: Phone): Call<Phone>

    @POST("emails")
    fun addEmail(@Body email: Email): Call<Email>

    @POST("personas/{id}/profile-picture")
    @Multipart
    fun uploadProfilePicture(
        @Path("id") id: Int,
        @Part image: MultipartBody.Part
    ): Call<Void>
}
