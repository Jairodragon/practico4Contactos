package com.example.practico4

class Constants {
}