package com.example.practico4

import android.os.Bundle
import android.util.Log
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.practico4.API.ApiClient
import com.example.practico4.Models.Contact
import com.example.practico4.Models.Email
import com.example.practico4.Models.Phone
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class CreateContactActivity : AppCompatActivity() {

    private lateinit var phoneContainer: LinearLayout
    private lateinit var emailContainer: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.createcontact)

        phoneContainer = findViewById(R.id.phone_container)
        emailContainer = findViewById(R.id.email_container)

        findViewById<Button>(R.id.add_phone_button).setOnClickListener {
            addPhoneField()
        }

        findViewById<Button>(R.id.add_email_button).setOnClickListener {
            addEmailField()
        }

        findViewById<Button>(R.id.save_contact_button).setOnClickListener {
            saveContact()
        }
    }

    private fun addPhoneField() {
        val inflater = layoutInflater
        val phoneView = inflater.inflate(R.layout.phone_item, phoneContainer, false)

        val phoneLabelSpinner = phoneView.findViewById<Spinner>(R.id.phone_label_spinner)
        val labels = arrayOf("Casa", "Trabajo", "Celular")
        phoneLabelSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)

        phoneContainer.addView(phoneView)
    }

    private fun addEmailField() {
        val inflater = layoutInflater
        val emailView = inflater.inflate(R.layout.email_item, emailContainer, false)

        val emailLabelSpinner = emailView.findViewById<Spinner>(R.id.email_label_spinner)
        val labels = arrayOf("Persona", "Trabajo", "Universidad")
        emailLabelSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)

        emailContainer.addView(emailView)
    }

    private fun saveContact() {
        val name = findViewById<EditText>(R.id.contact_name).text.toString()
        val lastName = findViewById<EditText>(R.id.contact_last_name).text.toString()
        val company = findViewById<EditText>(R.id.company_edit_text).text.toString()
        val address = findViewById<EditText>(R.id.address_edit_text).text.toString()
        val city = findViewById<EditText>(R.id.city_edit_text).text.toString()
        val state = findViewById<EditText>(R.id.state_edit_text).text.toString()

        // Collect phones
        val phones = mutableListOf<Phone>()
        for (i in 0 until phoneContainer.childCount) {
            val phoneView = phoneContainer.getChildAt(i)
            val phoneNumber = phoneView.findViewById<EditText>(R.id.phone_number).text.toString()
            val phoneLabel = phoneView.findViewById<Spinner>(R.id.phone_label_spinner).selectedItem.toString()
            phones.add(Phone(0, phoneLabel, phoneNumber))
        }

        // Collect emails
        val emails = mutableListOf<Email>()
        for (i in 0 until emailContainer.childCount) {
            val emailView = emailContainer.getChildAt(i)
            val emailAddress = emailView.findViewById<EditText>(R.id.email_address).text.toString()
            val emailLabel = emailView.findViewById<Spinner>(R.id.email_label_spinner).selectedItem.toString()
            emails.add(Email(0, emailAddress, emailLabel))
        }

        // Create the new contact
        val newContact = Contact(0, name, lastName, company, address, city, state, phones, emails)

        val apiService = ApiClient.apiService
        apiService.addContact(newContact).enqueue(object : Callback<Contact> {
            override fun onResponse(call: Call<Contact>, response: Response<Contact>) {
                if (response.isSuccessful) {
                    finish()
                } else {
                    Log.e("API_ERROR", "Error code: ${response.code()}, message: ${response.message()}")
                    Toast.makeText(this@CreateContactActivity, "Error al guardar el contacto: ${response.message()}", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<Contact>, t: Throwable) {
                Log.e("NETWORK_ERROR", "Error: ${t.message}")
                Toast.makeText(this@CreateContactActivity, "Error de red: ${t.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }
}
