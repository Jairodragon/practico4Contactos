package com.example.practico4.Models

data class Contact(
    val id: Int,
    val name: String,
    val lastName: String,
    val company: String,
    val address: String,
    val city: String,
    val state: String,
    val phones: List<Phone>,
    val emails: List<Email>
)
